<?php
class Usaha_model extends CI_Model
{
    public function getAllUsaha()
    {
        return $this->db->get('bidang_usaha')->result_array();
    }
}
