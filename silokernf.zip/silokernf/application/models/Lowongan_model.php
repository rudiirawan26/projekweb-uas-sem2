<?php
class Lowongan_model extends CI_Model
{
    public function getAllLowongan()
    {
        return $this->db->get('lowongan')->result_array();
    }

    public function tambahdataLoker()
    {
        $data = [
            "nama" => $this->input->post('nama', true),
            "email" => $this->input->post('email', true),
            "contact" => $this->input->post('contact', true),
        ];
        $this->db->insert()('lowongan', $data);
    }
}
