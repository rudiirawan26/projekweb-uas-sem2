<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Daftarmitra extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Mitra_model');
    }
    public function index()
    {
        $data['title'] = 'Daftar Mitra';
        $data['mitra'] = $this->Mitra_model->getAllMitra();
        $data['title'] = 'Mitra Perusahaan';
        $this->load->view('templates/header_home', $data);
        $this->load->view('templates/navbar_home');
        $this->load->view('daftarmitra/index', $data);
        $this->load->view('templates/footer_home');
    }

    public function resgistrasiMitra()
    {
        $data['title'] = 'Registrasi Mitra';
        $data['mitra'] = $this->Mitra_model->getAllMitra();
        $this->load->view('templates/header_home', $data);
        $this->load->view('templates/navbar_home');
        $this->load->view('daftarmitra/registrasimitra', $data);
        $this->load->view('templates/footer_home');
    }
}
