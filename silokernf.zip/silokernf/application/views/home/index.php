<!-- Carousel -->
<div class="container">
    <div class="row master-contet">
        <div class="col-lg-9">
            <div id="carouselExampleIndicators" class="carousel slide rounded-top" data-ride="carousel">
                <div class="container">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="row">
                                <div class="col-lg-7 carousel-welcome">
                                    <h1>Project by
                                        KELOMPOK 3</h1>
                                    <p>Project SILOKERNF di buat Kelompok 3 dari kelas SI03 yang beranggotakan:
                                    </p>
                                    <br>
                                    <a href="profile_kelompok.html" type="button" class="btn btn-crousel">Daftar
                                        Kelompok</a>
                                </div>
                                <div class="col img-carousel">
                                    <img src="<?= base_url('assets/'); ?>img/carousel/slide1.png" class="img-fluid carousel-img" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="row">
                                <div class="col-lg-7 carousel-welcome">
                                    <h1>Selamat Datang
                                        di SILOKERNF</h1>
                                    <p>Hanya Disini Kamu Bisa mencari Lowongan Pekerjaan yang Terpercaya dengan Gaji
                                        yang Kompetitif Sesuai dengan Keahlian Kamu!</p>
                                    <a href="loker_baru.html" type="button" class="btn btn-crousel">Cari
                                        Sekarang</a>
                                </div>
                                <div class="col img-carousel">
                                    <img src="<?= base_url('assets/'); ?>img/carousel/slide2.png" class="img-fluid carousel-img" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="row">
                                <div class="col-lg-7 carousel-welcome">
                                    <h1>Ayo Bergabung
                                        di SILOKERNF</h1>
                                    <p>Tunggu Apalagi? Segera Daftarkan Diri Kamu dan Login! <br>
                                        <b>Welcome To The World!</b>
                                    </p>
                                    <a href="login.html" type="button" class="btn btn-crousel">Daftar Sekarang</a>
                                </div>
                                <div class="col img-carousel">
                                    <img src="<?= base_url('assets/'); ?>img/carousel/slide3.png" class="img-fluid carousel-img" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only ">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <!-- Akhir Carousel -->


            <!-- Berita Terbaru -->
            <div class="container">
                <div class="row bg-white rounded-bottom berita-baru-master">
                    <div class="col-sm pusat-berita-terbaru">
                        <div class="row">
                            <a href="berita.html" class="berita_link">
                                <div class="col heading-berita-terbaru">
                                    <h2>Berita Terbaru 1</h2>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="mb-3 konten-berita-terbaru">
                                    <div class=" row no-gutters">
                                        <div class="col-md-4 img-thumb-terbaru">
                                            <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-terbaru/1.png" class="card-img img-fluid" alt="...">
                                        </div>
                                        <div class="col-md-8 isi-berita-terbaru">
                                            <div class="card-body judul-konten-berita-terbaru">
                                                <h5 class="">Kompetensi Menjadi Kata Kunci Penting di Dunia Kerja
                                                    Saat Ini</h5>
                                                <p class="ket-konten-berita-terbaru">Kompetensi merupakan kata kunci
                                                    penting di dunia kerja saat ini. Selain berguna untuk
                                                    meningkatkan daya saing dan produktivitas nasional. </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                    <div class="col pusat-berita-terbaru">
                        <div class="row">
                            <a href="berita.html" class="berita_link">
                                <div class="col heading-berita-terbaru">
                                    <h2>Berita Terbaru 2</h2>
                                </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="mb-3 konten-berita-terbaru">
                                    <div class="row no-gutters">
                                        <div class="col-md-4 img-thumb-terbaru">
                                            <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-terbaru/2.png" class="card-img img-fluid" alt="...">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body judul-konten-berita-terbaru">
                                                <h5 class="judul-ber-terbaru">9 Cara Agar Tetap Semangat Jalani
                                                    Karier</h5>
                                                <p class="ket-konten-berita-terbaru">Waktu berlalu begitu cepat
                                                    hingga mungkin akhirnya Anda menyadari sudah memasuki usia 30
                                                    tahun. Bahkan 40 tahun. Tak terasa juga Anda telah berkarier
                                                    cukup lama.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </a>
                </div>
            </div>
            <!-- Akhir Berita Terbaru -->
        </div>



        <!-- Postingan Populer -->
        <div class="col-lg-3">
            <div class="postingan-populer rounded-bottom">
                <h4 class="list-group-item list-group-item-action list-group-header">Postingan Populer</h4>
                <a href="berita.html" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-populer/1.png" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-sm- col-md-10 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">Tips Mudah Cari Kerja buat Mahasiswa dari Menaker</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">2 Januari 2021, 10.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="berita.html" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-populer/2.png" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-sm- col-md-10 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">Dunia Industri Didorong Tingkatkan Kualitas Pelatihan Vokasi</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">3 Januari 2021, 08.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="berita.html" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-populer/3.png" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-sm- col-md-10 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">5 Cara Milenial Mempengaruhi Dunia Kerja di 2021</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">13 Januari 2021, 14.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="berita.html" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-populer/4.png" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-sm- col-md-10 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">Riset Menunjukan Bahwa 37 Persen Tenaga Kerja Dunia Adalah...</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">21 Januari 2020, 23.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="berita.html" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-populer/5.png" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-sm- col-md-10 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">Tips agar Tetap Selalu Bahagia Saat Terjun di Dunia Kerja!</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">4 November 2020, 18.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
                <a href="berita.html" class="list-group-item list-group-item-action grup-post-populer">
                    <div class="">
                        <div class="row">
                            <div class="col-2 col-sm- col-md-2 col-lg-3 col-xl-3 img-popular-thumb">
                                <img src="<?= base_url('assets/'); ?>img/thumbnail/Berita-populer/6.png" class="img-fluid" alt="...">
                            </div>
                            <div class="col-7 col-md-8 col-lg-9 col-xl-9">
                                <div class="ket-populer">
                                    <h5 class="">Hal yang Wajib Dimiliki Setiap Individu agar Siap Hadapi Dunia
                                        Kerja...</h5>
                                    <p class=""></p>
                                    <p class="card-text"><small class="text-muted">28 September 2020, 17.00</small>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <!-- Akhir Postingan Populer -->
</div>