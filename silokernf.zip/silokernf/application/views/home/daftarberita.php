<!-- Halaman Daftar Berita  -->
<div class="container" style="margin-top: 70px;">
    <div class="row">
        <div class="col-lg-9">
            <div class="card border-0" style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);">
                <div class="card-header text-center p-1 border-0">
                    <h5>Kumpulan
                        Berita</h5>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card m-3 border-0 ">
                            <div class="row no-gutters ">
                                <div class="col-md-4">
                                    <a href=""><img src="<?= base_url('assets/'); ?>img/thumbnail/Daftar-berita/1.png" class="card-img" alt="..."></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body pb-0 pt-1">
                                        <a href="berita.html">
                                            <h5 class="card-title jud-daf-berita" style="color: rgb(86, 97, 243);">
                                                <b>Hal yang
                                                    Wajib Dimiliki Setiap Individu agar Siap Hadapi Dunia Kerja yang
                                                    Dinamis</b>
                                            </h5>
                                        </a>
                                        <p class="card-text ket-daf-berita">Dunia kerja merupakan tempat yang
                                            bekerja dengan cara
                                            dinamis. Oleh karena itu, setiap individu harus memiliki penguasaan
                                            keterampilan yang menjadi syarat, dalam menghadapi dunia
                                            ketenagakerjaan.
                                        </p>
                                        <p class="card-text"><small class="text-muted">Last updated 10 mins
                                                ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card m-3 border-0">
                            <div class="row no-gutters ">
                                <div class="col-md-4">
                                    <a href=""><img src="<?= base_url('assets/'); ?>img/thumbnail/Daftar-berita/2.png" class="card-img" alt="..."></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body pb-0 pt-1">
                                        <a href="berita.html">
                                            <h5 class="card-title jud-daf-berita" style="color: rgb(86, 97, 243);">
                                                <b>Tips agar
                                                    Tetap Bahagia Saat Terjun di Dunia Kerja!</b>
                                            </h5>
                                        </a>
                                        <p class="card-text ket-daf-berita">Punya pekerjaan yang sesuai dengan
                                            keahlian dan
                                            keinginan tentu jadi impian banyak orang. Itulah mengapa sebaiknya cari
                                            pekerjaan yang sesuai dengan keterampilan yang Anda miliki. </p>
                                        <p class="card-text"><small class="text-muted">Last updated 8 mins
                                                ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card m-3 border-0">
                            <div class="row no-gutters ">
                                <div class="col-md-4">
                                    <a href=""><img src="<?= base_url('assets/'); ?>img/thumbnail/Daftar-berita/3.png" class="card-img" alt="..."></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body pb-0 pt-1">
                                        <a href="berita.html">
                                            <h5 class="card-title jud-daf-berita" style="color: rgb(86, 97, 243);">
                                                <b>Riset
                                                    Menunjukan Bahwa 37 Persen Tenaga Kerja Dunia Adalah Pekerja
                                                    Mobile</b>
                                            </h5>
                                        </a>
                                        <p class="card-text ket-daf-berita">Kemajuan inovasi teknologi yang begitu
                                            pesat dan
                                            pengaruh gaya hidup generasi milenial yang semakin kuat telah mengubah
                                            lanskap bisnis dunia dan berdampak nyata terhadap beragam industri...
                                        </p>
                                        <p class="card-text"><small class="text-muted">Last updated 19 mins
                                                ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card m-3 border-0">
                            <div class="row no-gutters ">
                                <div class="col-md-4">
                                    <a href=""><img src="<?= base_url('assets/'); ?>img/thumbnail/Daftar-berita/4.png" class="card-img" alt="..."></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body pb-0 pt-1">
                                        <a href="berita.html">
                                            <h5 class="card-title jud-daf-berita" style="color: rgb(86, 97, 243);">
                                                <b>5 Cara
                                                    Milenial Mempengaruhi Dunia Kerja di 2021</b>
                                            </h5>
                                        </a>
                                        <p class="card-text ket-daf-berita">Generasi milenial telah melakukan banyak
                                            perubahan
                                            dalam dunia kerja selama lebih dari satu dekade. Berbagai gagasan dan
                                            karakter terjadi di dunia kerja. Namun, generasi ini kian bertambah
                                            usia.</p>
                                        <p class="card-text"><small class="text-muted">Last updated 7 mins
                                                ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card m-3 border-0">
                            <div class="row no-gutters ">
                                <div class="col-md-4">
                                    <a href=""><img src="<?= base_url('assets/'); ?>img/thumbnail/Daftar-berita/5.png" class="card-img" alt="..."></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body pb-0 pt-1">
                                        <a href="berita.html">
                                            <h5 class="card-title jud-daf-berita" style="color: rgb(86, 97, 243);">
                                                <b>Dunia
                                                    Industri Didorong Tingkatkan Kualitas Pelatihan Vokasi</b>
                                            </h5>
                                        </a>
                                        <p class="card-text ket-daf-berita">Pemerintah mendorong dunia industri
                                            (swasta) agar
                                            membantu pendidikan maupun pelatihan vokasi di sekolah kejuruan dan
                                            Balai Latihan Kerja untuk mempercepat peningkatan kompetensi dari tenaga
                                            kerja Indonesia.</p>
                                        <p class="card-text"><small class="text-muted">Last updated 26 mins
                                                ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="card m-3 border-0">
                            <div class="row no-gutters ">
                                <div class="col-md-4">
                                    <a href=""><img src="<?= base_url('assets/'); ?>img/thumbnail/Daftar-berita/6.png" class="card-img" alt="..."></a>
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body pb-0 pt-1">
                                        <a href="berita.html">
                                            <h5 class="card-title jud-daf-berita" style="color: rgb(86, 97, 243);">
                                                <b>Tips Mudah
                                                    Cari Kerja buat Mahasiswa dari Menaker
                                                </b>
                                            </h5>
                                        </a>
                                        <p class="card-text ket-daf-berita">Menteri Ketenagakerjaan M Hanif Dhakiri
                                            membeberkan
                                            rahasia sukses kepada para mahasiswa Indonesia agar berhasil menembus
                                            dunia kerja yang penuh persaingan. Salah satunya dengan memperluas
                                            jaringan.</p>
                                        <p class="card-text"><small class="text-muted">Last updated 8 mins
                                                ago</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr class="m-0" style="color: #f3f3f3;">

                <!-- Pagination -->
                <nav aria-label="...">
                    <ul class="pagination justify-content-center mt-3" style="transform: scale(0.9);">
                        <li class="page-item disabled">
                            <span class="page-link">Previous</span>
                        </li>
                        <li class="page-item active"><a class="page-link" href="daftar_berita.html">1</a></li>
                        <li class="page-item"><a class="page-link" href="daftar_berita_2.html">2</a></li>
                        <li class="page-item"><a class="page-link" href="daftar_berita_3.html">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="daftar_berita.html">Next</a>
                        </li>
                    </ul>
                </nav>
                <!-- Pagination -->
            </div>
        </div>
        <!-- Akhir Halaman Daftar Berita  -->


        <!-- Kategori Berita -->
        <div class="col-lg-3">
            <div class="card border-0 card-lowongan-pem">
                <div class="card-header p-1 border-0 text-center">
                    <h5>Kategori Berita</h5>
                </div>
                <div class="pem-list-cat-low">
                    <div class="list-kategori-lowongan">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a href="">Tips kejar karir 2021</a></li>
                            <li class="list-group-item"><a href="">Lowongan favorit 2020</a></li>
                            <li class="list-group-item"><a href="">Tips public speaking </a></li>
                            <li class="list-group-item"><a href="">Bisnis online</a></li>
                            <li class="list-group-item"><a href="">Digital marketing</a></li>
                            <li class="list-group-item"><a href="">Karyawan ideal 2021</a></li>
                            <li class="list-group-item"><a href="">Kriteria karyawan 2021</a></li>
                            <li class="list-group-item"><a href="">Penanaman saham</a></li>
                            <li class="list-group-item"><a href="">Tips bermain saham</a></li>
                            <li class="list-group-item"><a href="">Tips banyak relasi</a></li>
                            <li class="list-group-item"><a href="">Kriteria rekan bisnis</a></li>
                            <li class="list-group-item"><a href="">Tips jalani wfh</a></li>
                            <li class="list-group-item"><a href="">Kriteria bisnis </a></li>
                            <li class="list-group-item"><a href="">Akuntan publik</a></li>
                            <li class="list-group-item"><a href="">Pelatihan tenagakerja </a></li>
                            <li class="list-group-item"><a href="">Tips cari pelatihan</a></li>
                            <li class="list-group-item"><a href="">Perusahaan terbaik</a></li>
                            <li class="list-group-item"><a href="">Pekerjaan favorit 2020</a></li>
                            <li class="list-group-item"><a href="">UMR 2021</a></li>
                            <li class="list-group-item"><a href="">Tips naik gaji</a></li>
                            <li class="list-group-item"><a href="">Manufaktur terbaik</a></li>
                            <li class="list-group-item"><a href="">Otomotif Indonesia </a></li>
                    </div>
                    <li class="list-group-item">
                        <p class="card-text"><small class="text-muted text-center d-block"><a href="#">Lihat
                                    Lainnya..</a></small></p>
                    </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Akhir Kategori Berita -->