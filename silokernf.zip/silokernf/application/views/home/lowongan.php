Halaman Daftar Lowongan Baru -->
<div class="container" style="margin-top: 70px;">
    <div class="row mt-5">
        <div class="col-lg-9">
            <div class="card border-0 pem-kon-daf-loker pb-0">
                <div class="card-header text-center p-1 border-0">
                    <h5>Lowongan Kerja Terbaru di STT-NF</h5>
                </div>
                <div class="card mb-3 bg-transparent border-0 daf-loker">
                    <ul class="list-group">
                        <?php foreach ($lowongan as $loker) : ?>
                            <div class="row no-gutters">
                                <div class="col-md-3 card-image p-3">
                                    <img src="img/logo/logo_abc.png" class="img-fluid card-img-top" alt="...">
                                </div>
                                <div class="col-md-9">
                                    <div class="card-body ket-daf-loker">
                                        <h6 class="card-title-1">Lowongan PT ABC</h6>
                                        <h6 class="card-title-2"><?= $loker['deskripsi_pekerjaan'];  ?></h6>
                                        <h6>Kualifikasi</h6>
                                        <ul class="kualifikasi">
                                            <li>SI Bidang Komputer</li>
                                            <li>Menguasai Java, Spring Framework</li>
                                            <li>MySQL, PostareSQL</li>
                                        </ul>
                                        <p class="card-text"><small class="text-muted">14 Januari 2020, <a href="detail_loker_abc.html">Lihat
                                                    detail..</a></small></p>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                    </ul>
                </div>
                <hr class="m-2">
                <nav aria-label="...">
                    <ul class="pagination justify-content-center mb-2" style="transform: scale(0.7);">
                        <li class="page-item disabled">
                            <span class="page-link">Previous</span>
                        </li>
                        <li class="page-item active"><a class="page-link" href="loker_baru.html">1</a></li>
                        <li class="page-item"><a class="page-link" href="loker_baru_2.html">2</a></li>
                        <li class="page-item"><a class="page-link" href="loker_baru_3.html">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="loker_baru.html">Next</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <!-- Akhir Daftar Daftar Lowongan Baru  -->


        <!-- Kategori Lowongan -->
        <div class="col-lg-3">
            <div class="card border-0 card-lowongan-pem">
                <div class="card-header p-1 border-0 text-center">
                    <h5>Kategori Lowongan</h5>
                </div>
                <div class="pem-list-cat-low">
                    <div class="list-kategori-lowongan">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item"><a href="loker_baru.html">Programer & Developer</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Edukasi</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Pekerjaan Umum</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Administrasi</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Oprasional</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Akuntansi & Keunagan</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Designer</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Digital Marketing</a></li>
                            <li class="list-group-item"><a href="loker_baru.html">Content Marketing</a></li>
                    </div>
                    <li class="list-group-item">
                        <p class="card-text"><small class="text-muted text-center d-block"><a href="#">Lihat
                                    Lainnya..</a></small></p>
                    </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Akhir Kategori Lowongan