<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container container-utama">
        <a class="navbar-brand" href="#"><img src="<?= base_url('assets/'); ?>img/logo.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('home');  ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('lowongan');  ?>">Lowongan Baru</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('isiloker');  ?>">Isi Loker</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('daftarmitra');  ?>">Daftar Mitra</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('daftarberita/index');  ?>">Berita</a>
                </li>
            </ul>
            <div class="pembungkus-searchbox">
                <div class="searchbox">
                    <form class="get">
                        <div class="input-group">
                            <input class="form-control" type="text" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2" />
                            <div class="input-group-append ">
                                <button class="btn btn-search" type="button"><i class="fas fa-search text-white"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="btn-pembungkus"></div>
            <a href="<?= base_url('auth');  ?>"><button type="button" class="btn btn-login">Login</button></a>
        </div>
    </div>
</nav>
<!-- Akhir Navbar -->